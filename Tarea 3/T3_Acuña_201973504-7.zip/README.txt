Gabriela Acuña 

Rol 201973504-7

Circuito realizado en Logisim :)

- Se considero que los resultados negativos de las restas estan en 2 complemento