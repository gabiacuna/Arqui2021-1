Gabriela Acuña
Rol : 201973504-7

Ejecucion:
        python3 main.py

Si b es codigo, se asume que n esta codificado en el codigo b. Por lo tanto se decodifica y luego se traspasa a la base o codigo t. Explicado especificamente para cada caso en el informe.

* En la conclusion del informe sale la explicacion de todos los codigos y algunas bases mas importantes ya que se requeria en el pdf de la tarea, y luego note que no estaba en la pauta.
