Gabriela Acuña rol 201973504-7

Tarea realizada en :
		Logisim-evolution 3.4.5
Desde : 
		Manjaro Arch Linux

Cuando lo probe en win el archivo no abría por lo que adjunte pantallazos del circuito completo en el informe. Cualquier cosa mi mail es gabriela.acuna@usm.cl y estoy en el discord del ramo como Gabi Acuña.
